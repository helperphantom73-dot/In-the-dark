'use strict';
const $=id=>document.getElementById(id),cv=$('c'),g=cv.getContext('2d'),W=426,H=240,WORLD=2600;
cv.width=W;cv.height=H;
const lc=document.createElement('canvas');lc.width=W;lc.height=H;const lg=lc.getContext('2d');
const vg=document.createElement('canvas');vg.width=W;vg.height=H;
{const v=vg.getContext('2d'),r=v.createRadialGradient(W/2,H/2,H*.35,W/2,H/2,W*.62);r.addColorStop(0,'rgba(0,0,0,0)');r.addColorStop(1,'rgba(0,0,0,.85)');v.fillStyle=r;v.fillRect(0,0,W,H)}
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function rng(s){return()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const R=rng(7);
const trees=[[],[]];for(let l=0;l<2;l++)for(let x=-60;x<WORLD+700;x+=l?34:26)trees[l].push({x:x+R()*20,h:(l?74:52)+R()*40});
const fore=[];for(let x=300;x<WORLD+900;x+=330)fore.push({x:x+R()*140,w:12+R()*8});
const puddles=[];for(let i=0;i<26;i++)puddles.push({x:R()*WORLD,y:172+R()*60,w:14+R()*22});
const drops=[];for(let i=0;i<110;i++)drops.push({x:R()*W,y:R()*H,v:5+R()*4});
const laneY=z=>166+z*58,sc=z=>.8+z*.45;
let cam=0,t=0,band=0,light=true,tT=0,rush=0,still=0,check=200,started=false,dlgOn=false,ended=false,fade=0,spawned=false,read=false,got=false;
const P={x:200,z:.5,face:1,step:0},D={x:0,z:.5,on:false,face:1},trail=[];
function resetTrail(){trail.length=0;for(let i=0;i<240;i++)trail.push({x:P.x,z:P.z})}resetTrail();
const sx=x=>Math.round(x-cam);
const BANDS=[['104.2','REAL BAND','#9ec5d0'],['88.5','MEMORY BAND','#c0392b'],['99.9','THREAT BAND','#6fb59a']];
const MIM=['The bridge is completely out...','Evelyn... leave the car.','Mom? Are you in the tower?','Is that you?'];
const lock=()=>dlgOn||fade>0||ended||!started;
// ---------- audio ----------
let AC,NB,rainG,statG;
function audio(){if(AC)return;try{AC=new(window.AudioContext||window.webkitAudioContext)()}catch(e){return}
 NB=AC.createBuffer(1,AC.sampleRate*2,AC.sampleRate);const d=NB.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
 const mk=(type,f,q,v)=>{const s=AC.createBufferSource();s.buffer=NB;s.loop=true;s.start();const fl=AC.createBiquadFilter();fl.type=type;fl.frequency.value=f;fl.Q.value=q;const gn=AC.createGain();gn.gain.value=v;s.connect(fl);fl.connect(gn);gn.connect(AC.destination);return gn};
 rainG=mk('highpass',1400,.5,.1);statG=mk('bandpass',2200,.6,0)}
function foot(){if(!AC)return;const s=AC.createBufferSource();s.buffer=NB;const f=AC.createBiquadFilter();f.type='lowpass';f.frequency.value=320;const n=AC.createGain(),c=AC.currentTime;n.gain.setValueAtTime(.2,c);n.gain.exponentialRampToValueAtTime(.001,c+.12);s.connect(f);f.connect(n);n.connect(AC.destination);s.start(0,Math.random(),.15)}
function thump(fr){if(!AC)return;const o=AC.createOscillator(),n=AC.createGain(),c=AC.currentTime;o.frequency.value=fr;n.gain.setValueAtTime(.5,c);n.gain.exponentialRampToValueAtTime(.001,c+.25);o.connect(n);n.connect(AC.destination);o.start();o.stop(c+.3)}
// ---------- dialogue ----------
let Q=[],after=null,EN='',ty=0;
function say(q,cb){Q=q.slice();after=cb||null;dlgOn=true;K.l=K.r=K.u=K.d=0;$('dlg').style.display='block';nxt()}
function nxt(){if(!Q.length){dlgOn=false;$('dlg').style.display='none';const c=after;after=null;if(c)c();return}
 const[w,e,f]=Q.shift(),s=$('sp');s.textContent=w;s.style.color=w[0]=='E'?'#9ec5d0':w.startsWith('The D')?'#889':'#c0392b';EN=e;ty=0;$('fa').textContent=f;$('en').textContent=''}
function adv(){if(ty<EN.length)ty=EN.length;else nxt()}
let tt;function toast(s){const e=$('toast');e.textContent=s;e.style.opacity=1;clearTimeout(tt);tt=setTimeout(()=>e.style.opacity=0,3500)}
// ---------- input ----------
const K={};
function hold(id,k){const e=$(id);e.onpointerdown=ev=>{ev.preventDefault();K[k]=1;audio()};['pointerup','pointercancel','pointerleave'].forEach(n=>e['on'+n]=()=>K[k]=0)}
hold('bl','l');hold('br','r');hold('bu','u');hold('bd','d');
function tap(id,f){$(id).onpointerdown=ev=>{ev.preventDefault();audio();f()}}
function setDial(){if(lock())return;band=(band+1)%3;const b=BANDS[band];$('bn').textContent=b[0]+' MHz · '+b[1];$('bn').style.color=b[2];thump(120)}
tap('bdial',setDial);tap('blight',()=>{if(!lock()){light=!light;foot()}});tap('bact',act);
$('dlg').onpointerdown=adv;
const KM={ArrowLeft:'l',a:'l',ArrowRight:'r',d:'r',ArrowUp:'u',w:'u',ArrowDown:'d',s:'d'};
onkeydown=e=>{if(KM[e.key])K[KM[e.key]]=1;if(e.key=='e'||e.key=='Enter'||e.key==' ')act();if(e.key=='q')setDial();if(e.key=='f'&&!lock())light=!light;audio()};
onkeyup=e=>{if(KM[e.key])K[KM[e.key]]=0};
$('title').onpointerdown=()=>{if(started)return;started=true;$('title').style.display='none';audio();try{document.documentElement.requestFullscreen().catch(()=>{})}catch(e){}
 say([['Evelyn Mercer','The bridge is completely out... How is there a signal out here?','«پل کاملاً خراب شده... چطور اینجا سیگنال رادیویی هست؟»'],['Radio Voice (Static)','Evelyn... leave the car. The rain won\'t stop until you hear the tape.','«ایولین... ماشین رو رها کن. بارون بند نمیاد تا زمانی که نوار رو بشنوی.»']],()=>toast('Walk ◀▶▲▼ · DIAL changes the band · LIGHT · ACT'))};
$('end').onpointerdown=()=>location.reload();
// ---------- interactions ----------
const INTS=[
{x:240,f:()=>say([['Radio Voice (Static)','Tune the dial to 88.5, Evelyn. Listen to what the town remembers. Follow the road to Outpost 04.','«روی ۸۸.۵ تنظیم شو ایولین. به چیزی که شهر یادش مونده گوش بده. جاده رو تا ایستگاه ۴ ادامه بده.»']])},
{x:1450,f:()=>{if(band==1){read=true;check=1450;say([['Evelyn Mercer','"We were only following the sound of our own footsteps."','«ما فقط صدای قدم‌های خودمان را دنبال می‌کردیم.»'],['Evelyn Mercer','Outpost 04... the tape has to be there.','«ایستگاه ۴... نوار باید اونجا باشه.»']])}else say([['Evelyn Mercer','Scratches in the concrete... something is hidden beneath the noise.','«خراش روی بتنه... چیزی زیر نویز پنهونه.»']])}},
{x:2330,f:()=>{if(!read)return say([['Evelyn Mercer','The needle keeps drifting to 88.5. This place wants to be read first.','«عقربه مدام به ۸۸.۵ می‌چسبه. این‌جا می‌خواد اول خونده بشه.»']]);got=true;
 say([['Eleanor Mercer (Tape)','Evelyn... if this signal reaches you, turn back. Don\'t look for the Broadcast Spire. The Echo hasn\'t forgotten your voice.','«ایولین... اگه این سیگنال به دستت می‌رسه، برگرد. دنبال برج فرستنده نگرد. پژواک هنوز صداتو فراموش نکرده.»'],['Evelyn Mercer','...That\'s Mom. And the footsteps in the background... they\'re mine.','«...این مامانه. و اون قدم‌های پس‌زمینه... مال منه.»']],()=>{ended=true;$('end').style.display='flex'})}}];
const near=x=>Math.abs(P.x-x)<55;
function act(){if(dlgOn)return adv();if(lock())return;const i=INTS.find(i=>near(i.x));if(i)i.f()}
// ---------- update ----------
function update(){
 t++;const L=lock();
 const mx=L?0:(K.r?1:0)-(K.l?1:0),mz=L?0:(K.d?1:0)-(K.u?1:0);
 if(mx){P.x=clamp(P.x+mx*1.6,116,WORLD-30);P.face=mx}
 if(mz)P.z=clamp(P.z+mz*.012,0,1);
 if(mx||mz){P.step+=.25;still=0;if(t%15==0)foot()}else still++;
 trail.push({x:P.x,z:P.z});trail.shift();
 cam+=(clamp(P.x-W/2+P.face*40,0,WORLD-W)-cam)*.08;
 if(!L){if(band==2)tT+=1/60;else tT=Math.max(0,tT-1/120)}
 const hidden=!light&&still>90,nd=Math.abs(D.x-P.x);
 if(D.on&&!L){
  if(hidden){rush=0;tT=0}
  const sp=hidden?.2:rush>0?2.2:1.15,tg=rush>0?P:trail[0],dx=clamp(tg.x-D.x,-sp,sp);
  D.x+=dx;D.z+=clamp(tg.z-D.z,-sp*.01,sp*.01);if(dx)D.face=dx>0?1:-1;if(rush>0)rush--;
  if(!hidden&&tT>5){rush=240;tT=0;toast('THE DISTORTION: “'+MIM[(Math.random()*MIM.length)|0]+'”')}
  if(Math.abs(dx)>.3&&t%14==0&&nd<320)foot();
  if(nd<9&&Math.abs(P.z-D.z)<.25)fade=1}
 if(fade>0){fade++;if(fade>170){fade=0;P.x=check;P.z=.5;resetTrail();D.x=check-500;rush=0;tT=0;still=0}}
 if(!spawned&&P.x>800&&!L){spawned=true;check=800;say([['Evelyn Mercer','Those footsteps... they\'re mine. Something is walking exactly where I walked.','«اون قدم‌ها... مال منه. چیزی دقیقاً همون جاهایی راه میره که من رفتم.»'],['Radio Voice (Static)','Keep moving. Stand still and it finds you. Kill the light and hold your breath. Tune 99.9 to hear it... but not for long.','«حرکت کن. بایستی پیدات می‌کنه. چراغ رو خاموش کن و نفستو نگه دار. روی ۹۹.۹ می‌شنویش... ولی نه زیاد.»']],()=>{D.on=true;D.x=P.x-450;D.z=P.z;resetTrail()})}
 if(dlgOn&&ty<EN.length)ty=Math.min(EN.length,ty+.7);if(dlgOn)$('en').textContent=EN.slice(0,ty|0);
 $('bar').style.width=band==2?tT/5*100+'%':'0';
 $('bact').classList.toggle('on',!L&&INTS.some(i=>near(i.x)));
 if(AC){const c=AC.currentTime;statG.gain.setTargetAtTime([.004,.05,.07][band]+(D.on?clamp(1-nd/500,0,1)*.05:0),c,.1);
  if(band==2&&D.on&&!L&&t%Math.round(30+clamp(nd/6,0,80))==0){thump(55);setTimeout(()=>thump(45),140)}}
}
// ---------- drawing ----------
function pine(x,b,h,col){g.fillStyle=col;for(let i=0;i<h;i+=4){const w=Math.min(h*.26,i*.28+2);g.fillRect((x-w/2)|0,b-h+i,w|0,4)}}
let holes=[];
function human(x,z,face,step,col,hair){const y=laneY(z),s=sc(z);g.save();g.translate(sx(x),Math.round(y));g.fillStyle='#0006';g.fillRect(-7,-1,14,3);g.scale(face*s,s);
 const o=Math.round(Math.sin(step)*2);g.fillStyle='#14191c';g.fillRect(-3,-9,3,9+o);g.fillRect(1,-9,3,9-o);
 g.fillStyle=col;g.fillRect(-4,-21,9,13);g.fillRect(3,-20,3,8);g.fillStyle='#8a6a58';g.fillRect(-2,-28,6,6);
 g.fillStyle=hair;g.fillRect(-3,-29,7,3);g.fillRect(-3,-29,3,9);g.fillStyle='#e8e2c0';g.fillRect(5,-14,5,2);g.fillStyle='#c0392b';g.fillRect(-4,-10,3,3);g.restore()}
function car(x,z,col,lit){const y=laneY(z),s=sc(z),X=sx(x);g.save();g.translate(X,Math.round(y));g.scale(s,s);
 g.fillStyle='#0006';g.fillRect(-35,-2,70,5);g.fillStyle=col;g.fillRect(-32,-16,64,13);g.fillRect(-20,-27,40,12);
 g.fillStyle='#0b1418';g.fillRect(-17,-25,15,9);g.fillRect(2,-25,15,9);g.fillStyle='#050505';g.fillRect(-26,-6,10,7);g.fillRect(16,-6,10,7);
 g.fillStyle=lit?'#c0392b':'#401';g.fillRect(-32,-14,3,4);g.restore();if(lit)holes.push([X-30*s,y-10,34*s,.7])}
function ghost(x,z){const y=laneY(z),s=sc(z),X=sx(x);g.globalAlpha=.35+.2*Math.sin(t*.1+x);g.fillStyle='#c0392b';const j=(Math.random()*2)|0;g.fillRect(X-4+j,y-30*s,8*s,30*s);g.fillRect(X-3,y-36*s,6*s,6*s);g.globalAlpha=1}
function distortion(){const nd=Math.abs(D.x-P.x);let a=band==2?1:band==0&&nd<170&&((t>>2)%5<3)?.85:0;if(!a)return;
 const y=laneY(D.z),s=sc(D.z),X=sx(D.x);g.save();g.translate(X,Math.round(y));g.scale(s,s);g.globalAlpha=a;
 for(let i=0;i<38;i+=3){const o=(Math.sin(t*.3+i)*(rush>0?4:2))|0;g.fillStyle='#34454b';g.fillRect(-7+o,-38+i,14,3);g.fillStyle='#000';g.fillRect(-6+o,-38+i,12,3)}
 g.fillStyle='#000';g.fillRect(-11,-28,4,18);g.fillRect(7,-28,4,18);g.fillStyle='#c0392b';g.fillRect(-3,-34,2,1);g.fillRect(2,-34,2,1);
 if(band==2){const r=(t*.8*(1.4-clamp(nd/700,0,1)))%30;g.strokeStyle='rgba(192,57,43,'+(1-r/30)+')';g.beginPath();g.arc(0,-18,r,0,7);g.stroke()}
 g.restore()}
function hole(x,y,r,a){const q=lg.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,'rgba(0,0,0,'+a+')');q.addColorStop(1,'rgba(0,0,0,0)');lg.fillStyle=q;lg.fillRect(x-r,y-r,2*r,2*r)}
function draw(){
 holes=[];let q=g.createLinearGradient(0,0,0,150);q.addColorStop(0,'#05080b');q.addColorStop(1,'#1b2a30');g.fillStyle=q;g.fillRect(0,0,W,H);
 g.fillStyle='#6f8a9422';g.beginPath();g.arc(310-cam*.02,42,24,0,7);g.fill();
 for(let x=0;x<W;x+=3){const w=x+cam*.1,h=62+26*Math.sin(w*.011)+16*Math.sin(w*.037+2);g.fillStyle='#0e171b';g.fillRect(x,150-h,3,h)}
 trees[0].forEach(r=>{const x=r.x-cam*.3;if(x>-30&&x<W+30)pine(x,158,r.h,'#0a1215')});
 g.fillStyle='rgba(110,135,145,.10)';g.fillRect(0,100,W,70);
 trees[1].forEach(r=>{const x=r.x-cam*.6;if(x>-30&&x<W+30)pine(x,168,r.h,'#060b0d')});
 // outpost 04
 {const o=sx(2000),fl=Math.sin(t*.4)>-.6||t%97<8;g.fillStyle='#1c2528';g.fillRect(o,98,230,68);g.fillStyle='#10181b';g.fillRect(o-10,90,250,10);g.fillStyle='#050809';g.fillRect(o+100,130,26,36);g.fillRect(o+20,110,30,20);g.fillRect(o+170,110,30,20);
  g.fillStyle=fl?'#c0392b':'#4a1a15';g.fillRect(o+60,102,110,14);g.fillStyle='#000';g.font='9px monospace';g.fillText('OUTPOST 04',o+78,112);if(fl)holes.push([o+115,108,60,.8]);
  g.fillStyle='#3a4a50';g.fillRect(o-44,148,14,26);g.fillRect(o+240,148,14,26);g.fillStyle='#c0392b';g.fillRect(o-41,152,8,4)}
 // ground
 g.fillStyle='#0c1214';g.fillRect(0,156,W,H-156);g.fillStyle='#151b1e';g.fillRect(0,166,W,H-166);g.fillStyle='#2a3338';g.fillRect(0,164,W,2);g.fillRect(0,H-6,W,2);
 for(let w=Math.floor(cam/48)*48;w<cam+W+48;w+=48){g.fillStyle='#6f6330';g.fillRect(w-Math.round(cam),198,22,2)}
 puddles.forEach(p=>{const x=p.x-cam;if(x>-40&&x<W){g.fillStyle='rgba(120,150,165,'+(.08+.05*Math.sin(t*.05+p.x))+')';g.fillRect(x|0,p.y|0,p.w|0,2)}});
 // bridge void
 {const b=sx(110);if(b>0){g.fillStyle='#000';g.fillRect(0,150,b,H-150);for(let y=150;y<H;y+=6)g.fillRect(b,y,(Math.sin(y*.7)*4+4)|0,6);g.fillStyle='#3a2a22';g.fillRect(b-3,176,2,14);g.fillRect(b+1,200,2,10);g.fillStyle='rgba(120,140,150,.12)';g.fillRect(0,170,b,40)}}
 // lamps
 [520,1020,1520,2020].forEach((x,i)=>{const X=sx(x),on=Math.sin(t*.07+i*2)>-.8;g.fillStyle='#1a2124';g.fillRect(X,92,3,74);g.fillRect(X-8,90,14,3);if(on){g.fillStyle='#d9c98a';g.fillRect(X-8,93,10,2);holes.push([X-3,100,80,.95])}});
 // wall
 {const X=sx(1450);g.fillStyle='#222b2f';g.fillRect(X-60,112,120,52);g.fillStyle='#161d20';g.fillRect(X-60,108,120,4);g.fillRect(X-30,120,1,30);
  if(band==1){g.font='8px monospace';g.fillStyle='rgba(192,57,43,'+(.75+.25*Math.sin(t*.2))+')';g.fillText('WE WERE ONLY FOLLOWING',X-56,130);g.fillText('THE SOUND OF OUR OWN',X-56,141);g.fillText('FOOTSTEPS.',X-56,152)}else{g.fillStyle='#ffffff10';for(let i=0;i<9;i++)g.fillRect(X-50+i*11,126+(i%3)*8,8,1)}}
 // depth-sorted objects
 const it=[{z:.35,f:()=>car(240,.35,'#2a3a44',1)},{z:.12,f:()=>car(760,.12,'#3a2a2a',1)},{z:.8,f:()=>car(1180,.8,'#26333a',0)},{z:.3,f:()=>car(1700,.3,'#2f3a2c',1)},
  {z:P.z,f:()=>human(P.x,P.z,P.face,P.step,'#2f4a52','#3a2a22')}];
 if(band==1)it.push({z:.5,f:()=>ghost(700,.5)},{z:.25,f:()=>ghost(1230,.25)},{z:.6,f:()=>ghost(1660,.6)});
 if(!got)it.push({z:.5,f:()=>{const X=sx(2330),y=laneY(.5);g.fillStyle='#222';g.fillRect(X-12,y-12,24,12);g.fillStyle=(t>>4)%2?'#c0392b':'#7a2a20';g.fillRect(X-6,y-17,12,5);holes.push([X,y-12,30,.9])}});
 if(D.on)it.push({z:D.z,f:distortion});
 it.sort((a,b)=>a.z-b.z).forEach(o=>o.f());
 // lighting
 const px=sx(P.x),py=laneY(P.z);
 lg.globalCompositeOperation='source-over';lg.clearRect(0,0,W,H);lg.fillStyle='rgba(0,4,8,'+([.7,.88,.8][band]+(light?0:.1))+')';lg.fillRect(0,0,W,H);
 lg.globalCompositeOperation='destination-out';hole(px,py-14,light?38:16,.9);holes.forEach(h=>hole(h[0],h[1],h[2],h[3]));
 if(light&&!(band==2&&Math.random()<.04)){const x0=px+P.face*6,y0=py-16,ex=x0+P.face*150,gr=lg.createLinearGradient(x0,y0,ex,y0);gr.addColorStop(0,'rgba(0,0,0,.95)');gr.addColorStop(1,'rgba(0,0,0,0)');lg.fillStyle=gr;lg.beginPath();lg.moveTo(x0,y0);lg.lineTo(ex,y0-52);lg.lineTo(ex,y0+52);lg.fill()}
 g.drawImage(lc,0,0);
 if(band==1){g.fillStyle='rgba(120,20,20,.10)';g.fillRect(0,0,W,H)}if(band==2){g.fillStyle='rgba(20,70,55,.12)';g.fillRect(0,0,W,H)}
 // foreground depth, fog, rain
 fore.forEach(f=>{const x=f.x-cam*1.6;if(x>-30&&x<W+30){g.fillStyle='#020405';g.fillRect(x|0,-5,f.w,H+10)}});
 g.fillStyle='rgba(120,140,150,.06)';for(let i=0;i<4;i++)g.fillRect(0,130+i*22+Math.sin(t*.01+i)*6,W,14);
 g.fillStyle='rgba(170,190,210,.32)';drops.forEach(d=>{d.y+=d.v;d.x-=1.2;if(d.y>H){d.y=-6;d.x=Math.random()*W+20}g.fillRect(d.x|0,d.y|0,1,4)});
 g.drawImage(vg,0,0);g.fillStyle='rgba(0,0,0,.13)';for(let y=0;y<H;y+=2)g.fillRect(0,y,W,1);
 if(band==2&&Math.random()<.08){const y=Math.random()*H|0;g.drawImage(cv,0,y,W,12,(Math.random()*16-8)|0,y,W,12)}
 g.fillStyle='#000';g.fillRect(0,0,W,12);g.fillRect(0,H-12,W,12);
 if(fade>0){g.fillStyle='rgba(0,0,0,'+(fade<140?Math.min(1,fade/40):(170-fade)/30)+')';g.fillRect(0,0,W,H)}
 const c=$('caught');c.style.display=fade>30&&fade<150?'flex':'none';c.style.opacity=1;
}
let last=performance.now(),acc=0;
(function loop(n){acc+=Math.min(3,(n-last)/16.67);last=n;while(acc>=1){update();acc--}draw();requestAnimationFrame(loop)})(last);
